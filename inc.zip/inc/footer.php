<footer class="text-center mt-5 mb-3">
    <p>&copy; 2024 Kebun Data | Integrasi Teknologi dan Pertanian</p>
</footer>
