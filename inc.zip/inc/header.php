<?php
if(session_status() == PHP_SESSION_NONE){
    // Start Session it is not started yet
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../assets/img/kebunlogo_kecil.png">
    <title>Kebun Data | Aplikasi Monitoring Kegiatan</title>
</head>
<body>
    <nav class="navbar navbar-expand-sm navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../index.php">Kebun Data</a>
            <button class="navbar-toggler" type="text" data-bs-toggle="expand" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="true" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Daftar kegiatan</a>
                    </li>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <!-- Tampilkan menu Kelola Pengguna hanya untuk admin -->
                        <li class="nav-item">
                            <a class="nav-link" href="kelola_user.php">Kelola Pengguna</a>
                        </li>
                    <?php endif; ?>
                </ul>

                <ul class="navbar-nav ms-auto mr-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <span class="nav-link">Selamat datang, <?= $_SESSION['username'] ; ?>!</span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</body>
</html>
